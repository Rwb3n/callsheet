# CALLSHEET

> A modern B2B discovery and matching platform for production services.

## Project Structure

```
CALLSHEET/
│
├── 0-strategic-frame/
│   └── strategic-positioning.md                    ← LOCKED
│
├── 1-investigation/
│   ├── data-and-listings/
│   │   ├── taxonomy-analysis.md                    ← COMPLETE — 4rfv structural findings
│   │   ├── taxonomy-v1-proposal.md                 ← DRAFT v2 — revised with stress test fixes
│   │   ├── data-model-proposal.md                  ← DRAFT v2 — revised with gap fixes
│   │   ├── data-quality-framework.md               ← COMPLETE — scoring model, decay detection, enrichment cadence
│   │   ├── listing-decay-research.md               ← RAW RESEARCH — B2B decay benchmarks, Companies House data
│   │   ├── on-screen-talent-scope.md               ← INVESTIGATION BRIEF (Gap #4)
│   │   ├── on-screen-talent-scope-findings.md      ← FINDINGS COMPLETE — exclude individual talent, include B2B talent services
│   │   ├── on-screen-talent-scope-research.md      ← RAW RESEARCH — Spotlight, casting ecosystem, GDPR, expansion cases
│   │   ├── trust-verification-findings.md          ← FINDINGS COMPLETE — 4-tier framework, credit schema, GDPR, costs
│   │   ├── trust-verification-research.md          ← RAW RESEARCH — 7 platforms, Companies House API, IMDb, gaming prevention
│   │   └── trust-verification-framework.md         ← INVESTIGATION BRIEF (Gap #13/#14)
│   ├── platform-and-product/
│   │   ├── platform-investigation.md               ← INVESTIGATION BRIEF
│   │   ├── platform-architecture-decisions.md      ← ADR COMPLETE — V1 scope, stack, search, auth, ranking, infra, payments
│   │   ├── onboarding-flow-investigation.md        ← INVESTIGATION BRIEF (Gap #2)
│   │   └── onboarding-flow-findings.md            ← FINDINGS COMPLETE — unified account onboarding, 3 paths, progressive disclosure
│   ├── commercial-and-revenue/
│   │   ├── competitor-pricing-findings.md            ← FINDINGS COMPLETE — UK directory pricing, gaps, market size
│   │   ├── competitor-pricing-research.md            ← RAW RESEARCH — agent output
│   │   ├── analogous-directory-pricing-findings.md   ← FINDINGS COMPLETE — cross-market validation, pricing resolution
│   │   ├── analogous-directory-pricing-research.md   ← RAW RESEARCH — agent output
│   │   ├── freemium-conversion-findings.md           ← FINDINGS COMPLETE — tier structure, conversion targets
│   │   ├── freemium-conversion-benchmarks-research.md  ← RAW RESEARCH — agent output
│   │   ├── provider-buyer-duality-findings.md        ← FINDINGS COMPLETE — market network model, unified account, evolution path
│   │   └── provider-buyer-duality-research.md        ← RAW RESEARCH — agent output
│   └── operations/
│       ├── ops-investigation.md                    ← INVESTIGATION BRIEF
│       └── ops-model.md                            ← COMPLETE — solo ops blueprint, verification throughput, tooling, compliance, scaling triggers
│
├── 2-concept-design/                               ← PENDING
├── 3-requirements/                                 ← PENDING
└── 4-work-management/                              ← PENDING
```

## Current Status

**Phase:** Investigation COMPLETE  
**Focus:** All four investigation domains done. Ready for Concept Design.  
**Last activity:** Operations model complete — solo ops blueprint, verification throughput, tooling stack, UK compliance, revenue-linked scaling triggers

### Completed
- [x] Strategic frame locked
- [x] Domain mapping and priority sequencing
- [x] 4rfv taxonomy analysis (32 categories, structural findings)
- [x] V1 taxonomy proposal (7 sectors, ~50 service areas, ~200 specialisations)
- [x] Taxonomy stress test (16 real-world scenarios)
- [x] Gap fixes incorporated into taxonomy and data model
- [x] Freemium conversion research — tier structure, conversion targets, hard constraints
- [x] UK competitor pricing research — 4rfv, The Knowledge, Mandy, Kays, BECTU, market size
- [x] Analogous directory pricing research — cross-market validation (Clutch, Bark, Checkatrade, Yell, LinkedIn, Trustpilot, Houzz)
- [x] **Pricing decision resolved** — £199/£399/£699 annual confirmed (two independent streams converged)
- [x] Provider/buyer duality research — **Option E confirmed. Unified account architecture. Market network, not directory.**
- [x] Data quality framework — scoring model (5 dimensions, 0–100 composite), decay detection ruleset, enrichment cadence, escalation paths
- [x] Onboarding flow research — unified account onboarding, 3 paths (freelancer/company/claim), progressive disclosure, competitive analysis of 7 platforms
- [x] Trust/verification framework — 4-tier verification (Unclaimed→Claimed→Verified→Premium Verified), credit schema, Companies House API, GDPR, £75–85K first-year cost
- [x] On-screen talent scope — exclude individual talent from V1, include all talent-facing B2B services, architect for V2+. Taxonomy revision flagged.
- [x] Platform architecture decisions — V1 feature scope, Next.js/tRPC/Supabase/Better Auth/Paddle stack, PostgreSQL search, ranking algorithm, £36/mo launch cost
- [x] Operations model — solo ops blueprint, £0–31/mo tooling, 20–30 hrs/week, verification throughput, UK compliance, revenue-linked scaling triggers

### Investigation Phase Complete

All four domains investigated. 14 deliverables across Data & Listings, Commercial & Revenue, Platform & Product, and Operations.

### Next Phase
- [ ] Concept Design — wireframes, detailed specs, taxonomy revision (add talent-facing B2B categories), data model revision (add provider type field)

### Key Architectural Decision (from Duality Research)
- **Unified account model required at V1** — every user is both provider and buyer from account creation. Data model revision flagged for concept design phase.
- **Directory is launch vehicle, not business model** — V1→V2→V3 evolution path: directory fees → buyer-side premium → SaaS workflow tools
- **All commercial research complete** — four investigation streams converged on consistent model

### Not Started
- [ ] Platform & Product investigation (main)
- [ ] Operations investigation
- [ ] Concept design (all domains)
- [ ] Requirements
- [ ] Work management

## Domain Priority (V1)

| Priority | Domain | Status | Dependency |
|---|---|---|---|
| 1 | Data & Listings | **IN PROGRESS** | None |
| 2 | Platform & Product | Pending | Blocked by Data & Listings |
| 3 | Commercial & Revenue | Pending | Blocked by Platform & Product |
| 4 | Operations | Pending | Downstream of all |

## Stress Test Gap Tracker

| # | Gap | Severity | Status | Resolution |
|---|---|---|---|---|
| 1 | No genre/format tags | Medium | **FIXED** | "Works In" attribute added |
| 2 | Onboarding friction | High | **COMPLETE** | `onboarding-flow-findings.md` — unified account, 3 paths, progressive disclosure |
| 3 | No capacity/scale attributes | Medium | **FIXED** | Capacity indicators added to S6 |
| 4 | On-Screen Talent scope | High | **INVESTIGATION** | `on-screen-talent-scope.md` |
| 5 | Emerging services no home | Medium | **FIXED** | Free-text tags + review ceremony |
| 6 | Synonym/alias layer | Medium | **FIXED** | Search lookup table specified |
| 7 | Location model too simple | High | **FIXED** | Base + service regions + travel willingness |
| 8 | No entity lifecycle | Medium | **FIXED** | Lifecycle model with merge/rebrand/closure |
| 9 | No multi-location model | Medium | **FIXED** | Locations array on provider entity |
| 10 | Provider/buyer duality | High | **COMPLETE** | `provider-buyer-duality-findings.md` — Option E confirmed, unified account |
| 11 | Availability lacks seasonality | Low | **FIXED** | Seasonal patterns + lead time added |
| 12 | No jurisdiction attributes | Low | **FIXED** | Country/currency/tax regime attributes |
| 13 | Trust signals underspecified | High | **INVESTIGATION** | `trust-verification-framework.md` |
| 14 | Credits need structure | Medium | **FIXED** | Structured credits schema defined |
| 15 | Entity types underspecified | Medium | **FIXED** | 6-type enum defined |

## Documentation Pipeline

```
Strategic Frame → Investigation → Concept Design → Requirements → Work Management
   (locked)       (active)         (pending)        (pending)       (pending)
```
