# Work Management — Pending

**Status:** Not started  
**Blocked by:** Requirements phase completion

This directory will contain agile work management artifacts:

- Epics
- Stories / work items
- Sprint planning
- Acceptance criteria

Derived directly from requirements documentation.

## Entry Criteria

Requirements documents are complete and decomposable into discrete work items.
