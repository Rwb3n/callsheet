# Concept Design — Pending

**Status:** Not started  
**Blocked by:** Investigation phase completion

This directory will contain the 5-layer framework population for each V1 domain:

- `data-and-listings.md` — Principles → Ways of Working → Ceremonies → Activities → Assets
- `platform-and-product.md`
- `commercial-and-revenue.md`
- `operations.md`

Plus cross-domain dependency mapping:

- `cross-domain-dependencies.md`

## Entry Criteria

Investigation phase deliverables for all four V1 domains are complete and reviewed.
